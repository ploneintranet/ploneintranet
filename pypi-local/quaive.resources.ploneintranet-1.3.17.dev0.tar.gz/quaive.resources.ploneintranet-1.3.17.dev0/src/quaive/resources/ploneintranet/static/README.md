# Plone white label intranet

To edit the diazo template "home.html"
DO NOT EDIT THE generated/home.html.
Instead, edit the corresponding prototype page
and run 'make diazo'.
